class L
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		if(true)
		{
			System.out.println("if-block");
		}
		System.out.println("some thing");
		else
		{
			System.out.println("else block stmt1");
			System.out.println("else block stmt2");
			System.out.println("else block stmt3");
		}
		System.out.println("main end:");
	}
}
