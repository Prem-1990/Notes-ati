class A 
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		if(true)
		{
			System.out.println("if block");
		}
		else
		{
			System.out.println("else block");
		}
		System.out.println("main end");
	}
}
