class M
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		if(false);
		{
			System.out.println("if-block");
		}
		System.out.println("main end:");
	}
}
