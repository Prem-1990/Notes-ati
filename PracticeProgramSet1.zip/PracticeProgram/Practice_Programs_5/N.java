class N
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		if(false)
		if(false)			
			System.out.println("if2 body");			
		else			
			System.out.println("else2-body");			
		else		
			System.out.println("else1-body");		
		System.out.println("main end");
	}
}
