class Z7
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		if(false)
		if(true)
		if(true)				
		System.out.println("if3 begin");				
		System.out.println("main end");
	}
}
