class Z4
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		if(true)
		{
			if(true)
				if(false)				
					System.out.println("if3 begin");				
		}
		System.out.println("main end");
	}
}
