class K
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		if(true)
		{
			if(true)
				System.out.println("if2 begin");
		}
		System.out.println("main end");
	}
}
