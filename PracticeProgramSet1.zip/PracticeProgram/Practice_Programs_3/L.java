class L 
{
	public static void main(String[] args) 
	{
		int i = 0;
		System.out.println(true || (i++ == 0));
		System.out.println(i);
	}
}
