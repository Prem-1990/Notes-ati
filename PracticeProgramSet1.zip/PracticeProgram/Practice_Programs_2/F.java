class F
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		boolean b1;
		if(b1 = true)
		{
			System.out.println("from if");
		}
		System.out.println("main end");
	}
}
