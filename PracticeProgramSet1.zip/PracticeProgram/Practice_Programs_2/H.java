class H
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		boolean b1;
		if(b1 = false)
		{
			System.out.println("from if");
		}
		System.out.println("main end:" + b1);
	}
}
