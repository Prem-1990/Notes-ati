class Z6
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		int i = 10;
		if(i = 10)
		{
			System.out.println("from if1");
			System.out.println("from if2");
			System.out.println("from if3");
		}
		System.out.println("main end:" + i);
	}
}
