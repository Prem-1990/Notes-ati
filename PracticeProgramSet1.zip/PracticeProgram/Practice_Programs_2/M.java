class M
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		if(true)
		{
			System.out.println("from if1");
			System.out.println("from if2");
			System.out.println("from if3");
			System.out.println("from if4");
		}
		System.out.println("main end:");
	}
}
