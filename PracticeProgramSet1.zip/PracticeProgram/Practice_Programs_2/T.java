class T
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		if(true || false)
		{
			System.out.println("from if1");
			System.out.println("from if2");
			System.out.println("from if3");
		}
		System.out.println("main end:");
	}
}
