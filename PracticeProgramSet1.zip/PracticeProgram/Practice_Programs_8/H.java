class H
{
	public static void main(String[] args) 
	{
		int i = 200, j = 100;
		int min = i > j ? j : i;
		System.out.println("min b/w " + i + " and " + j + " is " + min);
	}
}
