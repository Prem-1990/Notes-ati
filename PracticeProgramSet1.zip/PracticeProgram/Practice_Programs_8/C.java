class C
{
	public static void main(String[] args) 
	{
		int i = true ? 10 : 20;
		System.out.println(i);
	}
}
